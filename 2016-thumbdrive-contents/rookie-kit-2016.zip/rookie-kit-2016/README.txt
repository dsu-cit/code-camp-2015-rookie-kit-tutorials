To run the starter kit, run client_pygame/main.py.
You should only make edits in files that do not tell you
not to.  The other files are provided in source code form
so that you may read them to see how to use the various
elements of the game.

