#
# Don't change this file
#
# ORDER MATTERS
from .game_message import *
from .object import *
from .missile import *
from .npc import *
from .player import *
from .wall import *
from .event import *
from .object_message import *
from .command_message import *
from .event_message import *
from .game_comm import *
from .game import *
